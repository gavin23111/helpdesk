// Exports the "autosave" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/autosave')
//   ES2015:
//     import 'tinymce/plugins/autosave'
require('./plugin.js');