/* ============================================================
   admin.js — FINAL (BAGIAN 1 / 4)
   Utilities • App state • DOM cache • Init & storage
   ============================================================ */

/* ===================== Utilities ===================== */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from((root || document).querySelectorAll(sel));

const el = (tag, props = {}, children = []) => {
  const e = document.createElement(tag);
  Object.entries(props || {}).forEach(([k, v]) => {
    if (k === 'class') e.className = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k === 'multiple' && v === true) e.multiple = true;
    else e.setAttribute(k, v);
  });
  (children || []).forEach(c => e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c));
  return e;
};

const debounce = (fn, ms = 250) => {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
};

/* Safe localStorage wrapper */
const store = {
  get(key, fallback = []) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.warn('store.get error', key, e);
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('store.set error', key, e);
    }
  }
};

/* ===================== App State & Cache ===================== */
const App = {
  username: store.get('username', 'admin') || 'admin',
  role: store.get('role', 'admin') || 'admin',
  reports: store.get('reports', []),
  history: store.get('history', []),
  activities: store.get('activities', []),
  accounts: store.get('accounts', []),
  teknisiList: [],
  ui: {},
  _assignSelectedTeknisi: null,
  _assignNoteEl: null
};

/* ===================== DOM Cache ===================== */
function cacheDOM() {
  App.ui = {
    sidebar: $('#sidebar'),
    toggleBtn: $('#toggleSidebar'),
    adminName: $('#adminName'),
    logoutBtn: $('#logoutBtn'),

    content: $('#mainContent'),
    sections: $$('#mainContent .section'),
    links: $$('#sidebar [data-link]'),

    // dashboard
    dashboardCards: $('#dashboardCards'),
    activityListAdmin: $('#activityListAdmin'),

    // search
    searchKeyword: $('#searchKeyword'),
    startDate: $('#startDate'),
    endDate: $('#endDate'),
    applyFilter: $('#applyFilter'),
    resetFilter: $('#resetFilter'),
    adminSearchResult: $('#adminSearchResult'),

    // reports
    reportTable: $('#reportTable'),
    searchActive: $('#searchActive'),
    filterStatus: $('#filterStatus'),

    // history
    historyTable: $('#historyTable'),
    searchHistory: $('#searchHistory'),
    filterTeknisi: $('#filterTeknisi'),

    // modals & assign
    detailModal: $('#detailModal'),
    detailContent: $('#detailContent'),
    detailHistory: $('#detailHistory'),
    adminButtons: $('#adminButtons'),
    assignBtn: $('#assignBtn'),
    pendingBtn: $('#pendingBtn'),
    finishBtn: $('#finishBtn'),
    closeDetailBtn: $('#closeDetailBtn'),

    assignModal: $('#assignModal'),
    searchTeknisi: $('#searchTeknisi'),
    dropdownTeknisi: $('#dropdownTeknisi'),
    tagContainer: $('#tagContainer'),
    assignNote: $('#assignNote'),
    confirmAssign: $('#confirmAssign'),

    teknisiCheckboxList: $('#teknisiCheckboxList') // legacy
  };
}

/* ===================== Initialization ===================== */
function initDefaults() {
  if (!App.accounts || App.accounts.length === 0) {
    App.accounts = [
      { username: 'admin', role: 'admin' },
      { username: 'teknisi1', role: 'teknisi' },
      { username: 'teknisi2', role: 'teknisi' }
    ];
    store.set('accounts', App.accounts);
  }
  App.teknisiList = App.accounts.filter(a => a.role === 'teknisi');
  if (App.ui && App.ui.adminName) App.ui.adminName.textContent = App.username || 'admin';
}

/* ===================== Storage sync/save ===================== */
function syncFromStorage() {
  App.reports = store.get('reports', []);
  App.history = store.get('history', []);
  App.activities = store.get('activities', []);
  App.accounts = store.get('accounts', []);
  App.teknisiList = App.accounts.filter(a => a.role === 'teknisi');
}

function saveAll() {
  store.set('reports', App.reports);
  store.set('history', App.history);
  store.set('activities', App.activities);
  store.set('accounts', App.accounts);

  // quick refresh
  renderReports();
  renderHistory();
  renderActivitiesAdmin();
  updateStats();
}

function pushActivity(text, by = App.username) {
  const act = { user: by, text, waktu: new Date().toLocaleString() };
  App.activities.unshift(act);
  if (App.activities.length > 300) App.activities.length = 300;
  store.set('activities', App.activities);
  renderActivitiesAdmin();
}

/* Helper escape */
function escapeHtml(str = '') {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

/* End Bagian 1 */
/* ============================================================
   admin.js — FINAL (BAGIAN 2 / 4)
   Renderers • Dashboard • Detail Modal
   ============================================================ */

/* format badge */
function formatBadge(status) {
  if (!status) return `<span class="badge">Dalam Antrean</span>`;
  const m = status.toLowerCase();
  if (m.includes('selesai')) return `<span class="badge" style="background:var(--success);color:#fff">${status}</span>`;
  if (m.includes('Diproses')) return `<span class="badge" style="background:#0ea5e9;color:#fff">${status}</span>`;
  if (m.includes('pending')) return `<span class="badge" style="background:var(--warning);color:#fff">${status}</span>`;
  return `<span class="badge">${status}</span>`;
}

/* Dashboard cards */
/* Dashboard cards — FIXED */
function updateStats() {
  const totalEl   = document.getElementById('totalTicket');
  const waitEl    = document.getElementById('waitingTicket');
  const procEl    = document.getElementById('processTicket');
  const doneEl    = document.getElementById('doneTicket');

  if (!totalEl || !waitEl || !procEl || !doneEl) return;

  syncFromStorage();

  const total = App.reports.length + App.history.length;

  const waiting = App.reports.filter(r =>
    !r.status || r.status === 'Menunggu' || r.status === 'Dalam Antrean'
  ).length;

  const process = App.reports.filter(r =>
    r.status === 'Diproses' ||
    r.status === 'Ditugaskan' ||
    r.status === 'Pending'
  ).length;

  const done = App.history.length;

  totalEl.textContent = total;
  waitEl.textContent = waiting;
  procEl.textContent = process;
  doneEl.textContent = done;
}


/* activities */
function renderActivitiesAdmin() {
  const listEl = App.ui.activityListAdmin;
  if (!listEl) return;
  listEl.innerHTML = '';
  const acts = (App.activities || []).slice(0, 25);
  if (!acts.length) {
    listEl.innerHTML = '<li class="text-muted">Belum ada aktivitas.</li>';
    return;
  }
  acts.forEach(a => {
    const li = el('li', {}, [
      el('small', { html: `<strong>${escapeHtml(a.text)}</strong><br><span class="text-muted">${escapeHtml(a.waktu)} — oleh: ${escapeHtml(a.user)}</span>` })
    ]);
    listEl.appendChild(li);
  });
}

/* render reports */
function renderReports() {
  syncFromStorage();
  const tbody = App.ui.reportTable;
  if (!tbody) return;
  tbody.innerHTML = '';

  const smallSearch = (App.ui.searchActive && App.ui.searchActive.value || '').toLowerCase();
  const statusFilter = App.ui.filterStatus ? App.ui.filterStatus.value : '';
  const cardKeyword = (App.ui.searchKeyword && App.ui.searchKeyword.value || '').toLowerCase();
  const startDate = App.ui.startDate && App.ui.startDate.value ? new Date(App.ui.startDate.value + 'T00:00:00') : null;
  const endDate = App.ui.endDate && App.ui.endDate.value ? new Date(App.ui.endDate.value + 'T23:59:59') : null;

  const items = App.reports.map((r, i) => ({ r, idx: i }))
    .filter(item => {
      const r = item.r;
      if (statusFilter && r.status !== statusFilter) return false;
      const targetFields = ((r.noTiket||'') + ' ' + (r.user||'') + ' ' + (r.judul||'')).toLowerCase();
      if (smallSearch && cardKeyword) {
        if (!(targetFields.includes(smallSearch) && targetFields.includes(cardKeyword))) return false;
      } else if (smallSearch) {
        if (!targetFields.includes(smallSearch)) return false;
      } else if (cardKeyword) {
        if (!targetFields.includes(cardKeyword)) return false;
      }
      if (startDate || endDate) {
        const d = r.tanggal ? new Date(r.tanggal) : null;
        if (!d || isNaN(d)) return false;
        if (startDate && d < startDate) return false;
        if (endDate && d > endDate) return false;
      }
      return true;
    });

  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">Tidak ada laporan aktif.</td></tr>`;
    return;
  }

  const frag = document.createDocumentFragment();
  items.forEach(item => {
    const r = item.r;
    const idx = item.idx;
const tr = el('tr', {}, [
  el('td', { html: escapeHtml(r.noTiket || '-') }),
  el('td', { html: escapeHtml(r.user || '-') }),
  el('td', { html: escapeHtml(r.unitKerja || '-') }),
  el('td', { html: escapeHtml(r.judul || '-') }),

  /* ===== URGENSI ===== */
  el('td', {
    html: r.urgensi
      ? `<span class="badge badge-light-${r.urgensi === 'Tinggi'
          ? 'danger'
          : r.urgensi === 'Sedang'
          ? 'warning'
          : 'success'}">${escapeHtml(r.urgensi)}</span>`
      : '<span class="badge badge-light-secondary">-</span>'
  }),

  /* ===== STATUS ===== */
  el('td', {
    html: r.status
      ? formatBadge(r.status)
      : '<span class="badge badge-light-secondary">Dalam Antrean</span>'
  }),

  el('td', { html: escapeHtml(r.tanggal || r.tanggalSelesai || '-') }),

  el('td', {}, [
    el('button', {
      class: 'btn btn-info btn-sm',
      'data-idx': idx
    }, ['Detail'])
  ])
]);


    frag.appendChild(tr);
  });
  tbody.appendChild(frag);

tbody.querySelectorAll('button[data-idx]').forEach(btn => {
  btn.addEventListener('click', () => {
    const idx = parseInt(btn.getAttribute('data-idx'), 10);
    modalMode = 'active';     // ✅
    selectedReportIndex = idx;
    showDetail(idx);
  });
});


}

/* render history */
function renderHistory() {
  syncFromStorage();
  const tbody = App.ui.historyTable;
  if (!tbody) return;
  tbody.innerHTML = '';

  const search = (App.ui.searchHistory && App.ui.searchHistory.value || '').toLowerCase();
  const teknisi = App.ui.filterTeknisi ? App.ui.filterTeknisi.value : '';

  const items = App.history.map((h, idx) => ({ h, idx }))
    .filter(item => {
      const h = item.h;
      const matchTeknisi = !teknisi || (h.teknisi && Array.isArray(h.teknisi) ? h.teknisi.join(', ').includes(teknisi) : (typeof h.teknisi === 'string' && h.teknisi.includes(teknisi)));
      const matchSearch = !search || ((h.judul||'').toLowerCase().includes(search) || (h.noTiket||'').toLowerCase().includes(search));
      return matchTeknisi && matchSearch;
    });

  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted">Belum ada riwayat laporan.</td></tr>`;
    return;
  }

  const frag = document.createDocumentFragment();
  items.forEach(it => {
    const r = it.h;
    const idx = it.idx;

const tr = el('tr', {}, [
  el('td', { html: escapeHtml(r.noTiket || '-') }),
  el('td', { html: escapeHtml(r.user || '-') }),
  el('td', { html: escapeHtml(r.unitKerja || '-') }),
  el('td', { html: escapeHtml(r.judul || '-') }),

  /* ===== URGENSI ===== */
  el('td', {
    html: r.urgensi
      ? `<span class="badge badge-light-${r.urgensi === 'Tinggi'
          ? 'danger'
          : r.urgensi === 'Sedang'
          ? 'warning'
          : 'success'}">${escapeHtml(r.urgensi)}</span>`
      : '<span class="badge badge-light-secondary">-</span>'
  }),

  /* ===== STATUS ===== */
  el('td', {
    html: r.status
      ? formatBadge(r.status)
      : '<span class="badge badge-light-secondary">Dalam Antrean</span>'
  }),

  el('td', { html: escapeHtml(r.tanggal || r.tanggalSelesai || '-') }),

  el('td', {}, [
    el('button', {
      class: 'btn btn-info btn-sm',
      'data-idx': idx
    }, ['Detail'])
  ])
]);


    frag.appendChild(tr);
  });
  tbody.appendChild(frag);

  tbody.querySelectorAll('button[data-idx]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      showHistoryDetail(idx);
    });
  });
}

/* populate teknisi filter */
function populateTeknisiFilter() {
  const sel = App.ui.filterTeknisi;
  if (!sel) return;
  sel.innerHTML = '<option value="">Semua Teknisi</option>';
  App.teknisiList.forEach(t => {
    sel.appendChild(el('option', { value: t.username, html: escapeHtml(t.username) }));
  });
}

/* detail modal functions */
let modalMode = 'active';
let selectedReportIndex = null;

function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('show');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('show');
}
function updateAdminButtons() {
  if (!App.ui.adminButtons) return;

  // hanya tampil jika benar-benar dari "Kelola Laporan"
  const shouldShow = modalMode === 'active';

  App.ui.adminButtons.style.display = shouldShow ? 'flex' : 'none';
}





function showDetail(index) {
  syncFromStorage();

  const r = App.reports[index];
  if (!r) return alert('Laporan tidak ditemukan.');

  selectedReportIndex = index;

App.ui.detailContent.innerHTML = `
  <p><strong>No Tiket:</strong> ${escapeHtml(r.noTiket || '-')}</p>
  <p><strong>User:</strong> ${escapeHtml(r.user || '-')}</p>
  <p><strong>Unit Kerja:</strong> ${escapeHtml(r.unitKerja || '-')}</p>
  <p><strong>Judul:</strong> ${escapeHtml(r.judul || '-')}</p>
  <p><strong>Urgensi:</strong> ${escapeHtml(r.urgensi || '-')}</p>
  <p><strong>Status:</strong> ${escapeHtml(r.status || 'Dalam Antrean')}</p>
  <p><strong>Tanggal Lapor:</strong> ${escapeHtml(r.tanggal || '-')}</p>
  <p><strong>Teknisi:</strong> ${
      r.teknisi
        ? Array.isArray(r.teknisi)
          ? r.teknisi.join(', ')
          : r.teknisi
        : '-'
    }</p>
  <p><strong>Catatan Admin:</strong> ${escapeHtml(r.notesAdmin || '-')}</p>
`;


  App.ui.detailHistory.innerHTML = '';
  (r.history || []).slice().reverse().forEach(h => {
    App.ui.detailHistory.innerHTML += `
      <li><small><strong>${escapeHtml(h.status)}</strong> — ${escapeHtml(h.waktu)}</small></li>
    `;
  });

  updateAdminButtons(); // 🔥 SATU-SATUNYA PENGONTROL
  openModal('detailModal');
}


function showDetailFromHistory(index) {
  const r = App.history[index];
  if (!r) return;

  modalMode = 'history';
updateAdminButtons();
openModal('detailModal');


  App.ui.detailContent.innerHTML = `
    <p><strong>No Tiket:</strong> ${escapeHtml(r.noTiket)}</p>
    <p><strong>User:</strong> ${escapeHtml(r.user)}</p>
    <p><strong>Judul:</strong> ${escapeHtml(r.judul)}</p>
    <p><strong>Status Akhir:</strong> ${escapeHtml(r.status)}</p>
  `;

  App.ui.detailHistory.innerHTML = '';

if (App.ui.adminButtons) {
  App.ui.adminButtons.style.display = 'none';
}



  openModal('detailModal');
}







/* history detail */
function showHistoryDetail(historyIndex) {
  modalMode = 'history';
  selectedReportIndex = null;

  const r = App.history[historyIndex];
  if (!r) return alert('Riwayat tidak ditemukan.');

App.ui.detailContent.innerHTML = `
  <p><strong>No Tiket:</strong> ${escapeHtml(r.noTiket || '-')}</p>
  <p><strong>User:</strong> ${escapeHtml(r.user || '-')}</p>
  <p><strong>Unit Kerja:</strong> ${escapeHtml(r.unitKerja || '-')}</p>
  <p><strong>Judul:</strong> ${escapeHtml(r.judul || '-')}</p>
  <p><strong>Urgensi:</strong> ${escapeHtml(r.urgensi || '-')}</p>
  <p><strong>Status Akhir:</strong> ${escapeHtml(r.status || '-')}</p>
  <p><strong>Tanggal Lapor:</strong> ${escapeHtml(r.tanggal || '-')}</p>
  <p><strong>Tanggal Selesai:</strong> ${escapeHtml(r.tanggalSelesai || '-')}</p>
  <p><strong>Teknisi:</strong> ${
    r.teknisi
      ? Array.isArray(r.teknisi)
        ? r.teknisi.join(', ')
        : r.teknisi
      : '-'
  }</p>
  <p><strong>Catatan Admin:</strong> ${escapeHtml(r.notesAdmin || '-')}</p>
`;


  App.ui.detailHistory.innerHTML = '';

  updateAdminButtons(); // ❌ history → otomatis HILANG
  openModal('detailModal');
}



/* End Bagian 2 */
/* ============================================================
   admin.js — FINAL (BAGIAN 3 / 4)
   Assign Modal (Option 2): search + dropdown + tags
   ============================================================ */

/* Open assign modal - modern multi-select */
function openAssignModal() {
  if (modalMode !== 'active' || selectedReportIndex === null) return;
  syncFromStorage();

  const r = App.reports[selectedReportIndex];

  const input = App.ui.searchTeknisi;
  const dropdown = App.ui.dropdownTeknisi;
  const tagBox = App.ui.tagContainer;
  const noteBox = App.ui.assignNote;
  const confirmBtn = App.ui.confirmAssign;

  if (!input || !dropdown || !tagBox || !confirmBtn) {
    // fallback: open assignModal if legacy select exists
    const legacy = document.getElementById('teknisiSelect');
    if (legacy) {
      openModal('assignModal');
      legacy.focus();
      return;
    }
    return alert('Form penugasan teknisi tidak lengkap di HTML.');
  }

  // initialize selected list (from report if any)
  let selected = Array.isArray(r.teknisi) ? [...r.teknisi] : (typeof r.teknisi === 'string' ? r.teknisi.split(',').map(s=>s.trim()).filter(Boolean) : []);
  App._assignSelectedTeknisi = selected;
  App._assignNoteEl = noteBox;

  input.value = '';
  tagBox.innerHTML = '';
  dropdown.innerHTML = '';

  // render tags
  function renderTags() {
    tagBox.innerHTML = '';
    selected.forEach(name => {
      const tag = document.createElement('div');
      tag.className = 'tag';
      tag.innerHTML = `${escapeHtml(name)} <span class="remove" data-name="${escapeHtml(name)}">×</span>`;
      tagBox.appendChild(tag);
    });
  }

  tagBox.onclick = (e) => {
    if (e.target.classList.contains('remove')) {
      const nm = e.target.dataset.name;
      selected = selected.filter(x => x !== nm);
      App._assignSelectedTeknisi = selected;
      renderTags();
    }
  };

  // render dropdown
  function renderDropdown(list) {
    dropdown.innerHTML = '';
    if (!list.length) {
      const empty = document.createElement('div');
      empty.className = 'dropdown-item text-muted';
      empty.textContent = 'Tidak ditemukan';
      dropdown.appendChild(empty);
      dropdown.style.display = 'block';
      return;
    }
    list.forEach(t => {
      const it = document.createElement('div');
      it.className = 'dropdown-item';
      it.textContent = t.username;
      it.onclick = () => {
        if (!selected.includes(t.username)) {
          selected.push(t.username);
          App._assignSelectedTeknisi = selected;
          renderTags();
        }
        dropdown.style.display = 'none';
        input.value = '';
      };
      dropdown.appendChild(it);
    });
    dropdown.style.display = list.length ? 'block' : 'none';
  }

  renderTags();
  renderDropdown(App.teknisiList);

  // search input handler
  input.oninput = debounce(() => {
    const q = input.value.trim().toLowerCase();
    const filtered = App.teknisiList.filter(t => t.username.toLowerCase().includes(q) && !selected.includes(t.username));
    renderDropdown(filtered);
  }, 80);

  // click outside to close dropdown
  function outsideListener(e) {
    if (e.target !== input && !dropdown.contains(e.target)) {
      dropdown.style.display = 'none';
    }
  }
  document.addEventListener('click', outsideListener);

  // confirm assign button handler (set here to close over selected)
  confirmBtn.onclick = () => {
    // ensure App._assignSelectedTeknisi up-to-date
    App._assignSelectedTeknisi = selected;
    confirmAssign();
    // remove listener
    document.removeEventListener('click', outsideListener);
  };

  openModal('assignModal');
  input.focus();
}

/* confirmAssign handles assign action (used by assign modal) */
function confirmAssign() {
  let selected = Array.isArray(App._assignSelectedTeknisi) ? App._assignSelectedTeknisi.slice() : null;
  const noteEl = App._assignNoteEl || document.getElementById('assignNote');

  if (!selected || selected.length === 0) return alert('Pilih minimal satu teknisi.');

  if (modalMode !== 'active' || selectedReportIndex === null) return;

  syncFromStorage();
  const r = App.reports[selectedReportIndex];
  if (!r) return alert('Laporan tidak ditemukan.');

  const catatan = noteEl && noteEl.value ? noteEl.value.trim() : '';

  // ✅ STATUS & TEKNISI
  r.status = 'Diproses';
  r.teknisi = selected.slice();

  // ✅ CATATAN ADMIN RESMI (UNTUK TEKNISI)
  r.notesAdmin = catatan;

  // ✅ HISTORY RESMI
  r.history = r.history || [];
  r.history.push({
    status: 'Diproses',
    waktu: new Date().toLocaleString(),
    oleh: App.username,
    teknisi: selected.slice(),
    catatan: catatan || null
  });

  saveAll();

  pushActivity(
    catatan
      ? `Menugaskan ${r.noTiket} ke (${selected.join(', ')}) — Catatan: ${catatan}`
      : `Menugaskan ${r.noTiket} ke (${selected.join(', ')})`
  );

  App._assignSelectedTeknisi = null;
  App._assignNoteEl = null;

  closeModal('assignModal');
  closeModal('detailModal');
  alert('Berhasil menugaskan teknisi.');
}


/* End Bagian 3 */
/* ============================================================
   admin.js — FINAL (BAGIAN 4 / 4)
   Actions • Search (fixed date+keyword) • Navigation • Boot
   ============================================================ */

/* mark pending */
function markPending() {
  if (modalMode !== 'active' || selectedReportIndex === null) return;

  syncFromStorage();
  const r = App.reports[selectedReportIndex];

  r.status = 'Pending';

  r.history = r.history || [];
  r.history.push({
    status: 'Pending',
    waktu: new Date().toLocaleString(),
    oleh: App.username
  });

  saveAll();
  pushActivity(`Mengubah status ${r.noTiket} menjadi Pending`);

  closeModal('detailModal');
  alert('Status diubah menjadi Pending.');
}

/* mark finish */
function markFinish() {
  if (modalMode !== 'active' || selectedReportIndex === null) return;

  syncFromStorage();
  const r = App.reports[selectedReportIndex];

  r.status = 'Selesai';
  r.tanggalSelesai = new Date().toLocaleString();

  r.history = r.history || [];
  r.history.push({
    status: 'Selesai',
    waktu: new Date().toLocaleString(),
    oleh: App.username
  });

  const archived = JSON.parse(JSON.stringify(r));

  App.history.unshift(archived);
  App.reports.splice(selectedReportIndex, 1);

  saveAll();
  pushActivity(`Menandai ${archived.noTiket} sebagai Selesai`);

  closeModal('detailModal');
  alert('Tiket dipindahkan ke riwayat.');
}

/* ===================== Admin Search (FIXED: keyword + date range) ===================== */
function adminSearch() {
  // read inputs
  const keyword = (App.ui.searchKeyword && App.ui.searchKeyword.value || '').toLowerCase().trim();
  const startDateVal = App.ui.startDate && App.ui.startDate.value ? App.ui.startDate.value : null;
  const endDateVal = App.ui.endDate && App.ui.endDate.value ? App.ui.endDate.value : null;
  const resultBox = App.ui.adminSearchResult;
  if (!resultBox) return;

  // gather tickets
  syncFromStorage();
  const all = [...App.reports, ...App.history];

  // helper to parse ticket date (attempt multiple formats)
  function parseTicketTime(t) {
    if (!t) return null;
    const tryDates = [t.tanggal || t.tanggalSelesai || t.time || t.date, t.tanggal];
    for (const v of tryDates) {
      if (!v) continue;
      const d = new Date(v);
      if (!isNaN(d)) return d;
      // try dd/mm/yyyy
      if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(v)) {
        const [dd, mm, yyyy] = v.split('/');
        const ddn = new Date(parseInt(yyyy,10), parseInt(mm,10)-1, parseInt(dd,10));
        if (!isNaN(ddn)) return ddn;
      }
    }
    return null;
  }

  const filtered = all.filter(t => {
    let matchKeyword = true;
    let matchDate = true;

    if (keyword) {
      const no = (t.noTiket||'').toLowerCase();
      const judul = (t.judul||'').toLowerCase();
      const user = (t.user||'').toLowerCase();
      matchKeyword = no.includes(keyword) || judul.includes(keyword) || user.includes(keyword);
    }

    if (startDateVal || endDateVal) {
      const td = parseTicketTime(t);
      if (!td) return false;
      if (startDateVal) {
        const s = new Date(startDateVal + 'T00:00:00');
        if (td < s) matchDate = false;
      }
      if (endDateVal) {
        // include entire day
        const e = new Date(endDateVal + 'T23:59:59');
        if (td > e) matchDate = false;
      }
    }

    return matchKeyword && matchDate;
  });

  if (!filtered.length) {
    resultBox.innerHTML = `<p class="text-danger fw-bold">Tidak ada tiket yang cocok.</p>`;
    return;
  }

  let html = `<table class="table table-striped mt-3"><thead><tr><th>No Tiket</th><th>Judul</th><th>User</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead><tbody>`;
  filtered.forEach(r => {
    html += `<tr>
      <td>${escapeHtml(r.noTiket || '-')}</td>
      <td>${escapeHtml(r.judul || '-')}</td>
      <td>${escapeHtml(r.user || '-')}</td>
      <td>${escapeHtml(r.status || '-')}</td>
      <td>${escapeHtml(r.tanggal || r.tanggalSelesai || '-')}</td>
      <td><button class="btn btn-sm btn-info" data-open="${escapeHtml(r.noTiket || '')}">Detail</button></td>
    </tr>`;
  });
  html += `</tbody></table>`;
  resultBox.innerHTML = html;

  // attach handlers
resultBox.querySelectorAll('button[data-open]').forEach(btn => {
  btn.addEventListener('click', () => {
    const no = btn.getAttribute('data-open');
    syncFromStorage();

    const idx = App.reports.findIndex(x => x.noTiket === no);
    if (idx !== -1) {
     modalMode = 'search';
selectedReportIndex = idx;
showDetail(idx);

      return;
    }

    const hIdx = App.history.findIndex(x => x.noTiket === no);
    if (hIdx !== -1) {
      modalMode = 'history';     // 🔥 INI
      showHistoryDetail(hIdx);
      return;
    }

    alert('Tiket tidak ditemukan.');
  });
});



}

/* Debounced wrapper */
const debouncedAdminSearch = debounce(adminSearch, 250);

/* ===================== Navigation / SPA ===================== */
function hideAllSections() {
  (App.ui.sections || []).forEach(s => s.classList.add('hidden'));
}
function setActiveLink(hash) {
  (App.ui.links || []).forEach(a => a.classList.remove('active'));
  const match = (App.ui.links || []).find(l => l.getAttribute('href') === hash);
  if (match) match.classList.add('active');
}
function navigateTo(hash, pushState = true) {
  hideAllSections();
  setActiveLink(hash);
  if (hash === '#dashboard') $('#dashboard-section').classList.remove('hidden');
  else if (hash === '#search') $('#search-section').classList.remove('hidden');
  else if (hash === '#laporan-aktif') $('#laporan-aktif-section').classList.remove('hidden');
  else if (hash === '#riwayat') $('#riwayat-section').classList.remove('hidden');
  else $('#dashboard-section').classList.remove('hidden');
  if (pushState) history.replaceState(null, '', hash);
  if (window.innerWidth <= 991 && App.ui && App.ui.sidebar) App.ui.sidebar.classList.remove('show');
}

/* ===================== Events binding ===================== */
function bindUI() {
  if (!App.ui) return;

  (App.ui.links || []).forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      const hash = a.getAttribute('href');
      navigateTo(hash);
    });
  });

  if (App.ui.toggleBtn) App.ui.toggleBtn.addEventListener('click', () => {
    if (window.innerWidth <= 991) App.ui.sidebar.classList.toggle('show');
    else { App.ui.sidebar.classList.toggle('hidden'); App.ui.content.classList.toggle('full'); }
  });

  if (App.ui.logoutBtn) App.ui.logoutBtn.addEventListener('click', logout);
  if (App.ui.closeDetailBtn) App.ui.closeDetailBtn.addEventListener('click', () => closeModal('detailModal'));
  if (App.ui.assignBtn) App.ui.assignBtn.addEventListener('click', openAssignModal);
  if (App.ui.confirmAssign) App.ui.confirmAssign.addEventListener('click', confirmAssign);
  if (App.ui.pendingBtn) App.ui.pendingBtn.addEventListener('click', markPending);
  if (App.ui.finishBtn) App.ui.finishBtn.addEventListener('click', markFinish);

  if (App.ui.searchActive) App.ui.searchActive.addEventListener('input', debounce(renderReports, 200));
  if (App.ui.filterStatus) App.ui.filterStatus.addEventListener('change', renderReports);
  if (App.ui.searchHistory) App.ui.searchHistory.addEventListener('input', debounce(renderHistory, 200));
  if (App.ui.filterTeknisi) App.ui.filterTeknisi.addEventListener('change', renderHistory);

  if (App.ui.applyFilter) App.ui.applyFilter.addEventListener('click', adminSearch);
if (App.ui.resetFilter) App.ui.resetFilter.addEventListener('click', () => {
  if (App.ui.searchKeyword) App.ui.searchKeyword.value = '';
  if (App.ui.startDate) App.ui.startDate.value = '';
  if (App.ui.endDate) App.ui.endDate.value = '';

  // 🔥 Bersihkan hasil pencarian
  if (App.ui.adminSearchResult)
    App.ui.adminSearchResult.innerHTML = '';

  renderReports();
});

  if (App.ui.searchKeyword) {
    App.ui.searchKeyword.addEventListener('keypress', (e) => { if (e.key === 'Enter') adminSearch(); });
    App.ui.searchKeyword.addEventListener('input', debouncedAdminSearch);
  }

  // storage sync across tabs
  window.addEventListener('storage', (e) => {
    if (['reports','history','activities','accounts'].includes(e.key) || e.key === null) {
      syncFromStorage();
      renderReports();
      renderHistory();
      renderActivitiesAdmin();
      updateStats();
      populateTeknisiFilter();
    }
  });

  // polling fallback
  setInterval(() => {
    const sReports = JSON.stringify(store.get('reports', []));
    if (sReports !== JSON.stringify(App.reports)) {
      syncFromStorage();
      renderReports();
      renderHistory();
      renderActivitiesAdmin();
      updateStats();
    }
  }, 2000);
}

/* ===================== Auth / Logout ===================== */
function logout() {
  try {
    localStorage.removeItem('username');
    localStorage.removeItem('role');
  } catch (e) {}
  window.location.href = 'login.html';
}

/* ===================== Boot ===================== */
function boot() {
  cacheDOM();
  initDefaults();
  bindUI();
  syncFromStorage();
  populateTeknisiFilter();
  renderActivitiesAdmin();
  renderReports();
  renderHistory();
  updateStats();

  // initial route
  if (!location.hash) navigateTo('#dashboard', false);
  else navigateTo(location.hash, false);

  // expose debug
  window.showDetail = showDetail;
  window.showHistoryDetail = showHistoryDetail;
  window.adminSearch = adminSearch;
  window.closeModal = closeModal;
}

document.addEventListener('DOMContentLoaded', boot);

/* End Bagian 4 */
